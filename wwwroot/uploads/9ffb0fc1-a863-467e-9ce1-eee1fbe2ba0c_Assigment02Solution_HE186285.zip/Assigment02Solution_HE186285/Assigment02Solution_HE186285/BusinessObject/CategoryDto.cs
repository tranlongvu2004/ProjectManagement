namespace BussiniseObject;

public class CategoryDto
{
    public string? CategoryName { get; set; }
}
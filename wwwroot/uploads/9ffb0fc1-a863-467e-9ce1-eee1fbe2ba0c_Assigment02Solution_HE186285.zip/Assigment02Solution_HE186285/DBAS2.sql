﻿-- Chuyển sang master để tạo CSDL
USE [master]
GO

-- Xóa CSDL nếu đã tồn tại để tạo mới hoàn toàn
IF EXISTS (SELECT name FROM sys.databases WHERE name = N'eStore')
BEGIN
    ALTER DATABASE [eStore] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE [eStore];
END
GO

-- Tạo cơ sở dữ liệu mới
CREATE DATABASE [eStore]
GO

-- Sử dụng CSDL eStore
USE [eStore]
GO

---------------------------------------------------
-- 1. TẠO CÁC BẢNG ASP.NET IDENTITY
---------------------------------------------------

-- AspNetUsers
CREATE TABLE [dbo].[AspNetUsers] (
    [Id]                   NVARCHAR (450) NOT NULL,
    [UserName]             NVARCHAR (256) NULL,
    [NormalizedUserName]   NVARCHAR (256) NULL,
    [Email]                NVARCHAR (256) NULL,
    [NormalizedEmail]      NVARCHAR (256) NULL,
    [EmailConfirmed]       BIT            NOT NULL,
    [PasswordHash]         NVARCHAR (MAX) NULL,
    [SecurityStamp]        NVARCHAR (MAX) NULL,
    [ConcurrencyStamp]     NVARCHAR (MAX) NULL,
    [PhoneNumber]          NVARCHAR (MAX) NULL,
    [PhoneNumberConfirmed] BIT            NOT NULL,
    [TwoFactorEnabled]     BIT            NOT NULL,
    [LockoutEnd]           DATETIMEOFFSET (7) NULL,
    [LockoutEnabled]       BIT            NOT NULL,
    [AccessFailedCount]    INT            NOT NULL,
    [FirstName]            NVARCHAR (MAX) NULL, -- Trường tùy chỉnh (FirstName)
    [LastName]             NVARCHAR (MAX) NULL,  -- Trường tùy chỉnh (LastName)
    CONSTRAINT [PK_AspNetUsers] PRIMARY KEY CLUSTERED ([Id] ASC)
);
GO
CREATE UNIQUE INDEX [UserNameIndex] ON [dbo].[AspNetUsers] ([NormalizedUserName]) WHERE [NormalizedUserName] IS NOT NULL;
GO
CREATE INDEX [EmailIndex] ON [dbo].[AspNetUsers] ([NormalizedEmail]);
GO

-- AspNetRoles
CREATE TABLE [dbo].[AspNetRoles] (
    [Id]                   NVARCHAR (450) NOT NULL,
    [Name]                 NVARCHAR (256) NULL,
    [NormalizedName]       NVARCHAR (256) NULL,
    [ConcurrencyStamp]     NVARCHAR (MAX) NULL,
    CONSTRAINT [PK_AspNetRoles] PRIMARY KEY CLUSTERED ([Id] ASC)
);
GO
CREATE UNIQUE INDEX [RoleNameIndex] ON [dbo].[AspNetRoles] ([NormalizedName]) WHERE [NormalizedName] IS NOT NULL;
GO

-- AspNetUserRoles
CREATE TABLE [dbo].[AspNetUserRoles] (
    [UserId] NVARCHAR (450) NOT NULL,
    [RoleId] NVARCHAR (450) NOT NULL,
    CONSTRAINT [PK_AspNetUserRoles] PRIMARY KEY CLUSTERED ([UserId] ASC, [RoleId] ASC),
    CONSTRAINT [FK_AspNetUserRoles_AspNetRoles_RoleId] FOREIGN KEY ([RoleId]) REFERENCES [dbo].[AspNetRoles] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_AspNetUserRoles_AspNetUsers_UserId] FOREIGN KEY ([UserId]) REFERENCES [dbo].[AspNetUsers] ([Id]) ON DELETE CASCADE
);
GO

-- AspNetUserClaims
CREATE TABLE [dbo].[AspNetUserClaims] (
    [Id]         INT            IDENTITY (1, 1) NOT NULL,
    [UserId]     NVARCHAR (450) NOT NULL,
    [ClaimType]  NVARCHAR (MAX) NULL,
    [ClaimValue] NVARCHAR (MAX) NULL,
    CONSTRAINT [PK_AspNetUserClaims] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_AspNetUserClaims_AspNetUsers_UserId] FOREIGN KEY ([UserId]) REFERENCES [dbo].[AspNetUsers] ([Id]) ON DELETE CASCADE
);
GO

-- AspNetRoleClaims
CREATE TABLE [dbo].[AspNetRoleClaims] (
    [Id]         INT            IDENTITY (1, 1) NOT NULL,
    [RoleId]     NVARCHAR (450) NOT NULL,
    [ClaimType]  NVARCHAR (MAX) NULL,
    [ClaimValue] NVARCHAR (MAX) NULL,
    CONSTRAINT [PK_AspNetRoleClaims] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_AspNetRoleClaims_AspNetRoles_RoleId] FOREIGN KEY ([RoleId]) REFERENCES [dbo].[AspNetRoles] ([Id]) ON DELETE CASCADE
);
GO

-- AspNetUserLogins
CREATE TABLE [dbo].[AspNetUserLogins] (
    [LoginProvider]       NVARCHAR (450) NOT NULL,
    [ProviderKey]         NVARCHAR (450) NOT NULL,
    [ProviderDisplayName] NVARCHAR (MAX) NULL,
    [UserId]              NVARCHAR (450) NOT NULL,
    CONSTRAINT [PK_AspNetUserLogins] PRIMARY KEY CLUSTERED ([LoginProvider] ASC, [ProviderKey] ASC),
    CONSTRAINT [FK_AspNetUserLogins_AspNetUsers_UserId] FOREIGN KEY ([UserId]) REFERENCES [dbo].[AspNetUsers] ([Id]) ON DELETE CASCADE
);
GO

-- AspNetUserTokens
CREATE TABLE [dbo].[AspNetUserTokens] (
    [UserId]        NVARCHAR (450) NOT NULL,
    [LoginProvider] NVARCHAR (450) NOT NULL,
    [Name]          NVARCHAR (450) NOT NULL,
    [Value]         NVARCHAR (MAX) NULL,
    CONSTRAINT [PK_AspNetUserTokens] PRIMARY KEY CLUSTERED ([UserId] ASC, [LoginProvider] ASC, [Name] ASC),
    CONSTRAINT [FK_AspNetUserTokens_AspNetUsers_UserId] FOREIGN KEY ([UserId]) REFERENCES [dbo].[AspNetUsers] ([Id]) ON DELETE CASCADE
);
GO

---------------------------------------------------
-- 2. TẠO CÁC BẢNG ỨNG DỤNG E-STORE
---------------------------------------------------

-- Category
CREATE TABLE [dbo].[Category](
	[CategoryId] [int] IDENTITY(1,1) NOT NULL,
	[CategoryName] [nvarchar](50) NOT NULL,
    CONSTRAINT [PK_Category] PRIMARY KEY CLUSTERED ([CategoryId] ASC)
);
GO

-- Product
CREATE TABLE [dbo].[Product](
	[ProductId] [int] IDENTITY(1,1) NOT NULL,
	[CategoryId] [int] NOT NULL,
	[ProductName] [nvarchar](100) NOT NULL,
	[Weight] [float] NULL,
	[UnitPrice] [money] NOT NULL,
	[UnitsInStock] [int] NOT NULL,
    CONSTRAINT [PK_Product] PRIMARY KEY CLUSTERED ([ProductId] ASC)
);
GO

-- Order (Sử dụng UserId NVARCHAR(450) thay cho MemberId INT)
CREATE TABLE [dbo].[Order](
	[OrderId] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [nvarchar](450) NOT NULL, -- Thay thế MemberId
	[OrderDate] [datetime] NOT NULL,
	[RequiredDate] [datetime] NULL,
	[ShippedDate] [datetime] NULL,
	[Freight] [money] NULL,
    CONSTRAINT [PK_Order] PRIMARY KEY CLUSTERED ([OrderId] ASC)
);
GO

-- OrderDetail
CREATE TABLE [dbo].[OrderDetail](
	[OrderId] [int] NOT NULL,
	[ProductId] [int] NOT NULL,
	[UnitPrice] [money] NOT NULL,
	[Quantity] [int] NOT NULL,
	[Discount] [float] NOT NULL,
    CONSTRAINT [PK_OrderDetail] PRIMARY KEY CLUSTERED ([OrderId] ASC, [ProductId] ASC)
);
GO

---------------------------------------------------
-- 3. THIẾT LẬP KHÓA NGOẠI (FOREIGN KEYS)
---------------------------------------------------

-- Khóa ngoại cho Product
ALTER TABLE [dbo].[Product] WITH CHECK ADD CONSTRAINT [FK_Product_Category] FOREIGN KEY([CategoryId])
REFERENCES [dbo].[Category] ([CategoryId]);
GO
ALTER TABLE [dbo].[Product] CHECK CONSTRAINT [FK_Product_Category];
GO

-- Khóa ngoại cho Order (Liên kết với AspNetUsers)
ALTER TABLE [dbo].[Order] WITH CHECK ADD CONSTRAINT [FK_Order_AspNetUser] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id]) ON DELETE CASCADE;
GO
ALTER TABLE [dbo].[Order] CHECK CONSTRAINT [FK_Order_AspNetUser];
GO

-- Khóa ngoại cho OrderDetail
ALTER TABLE [dbo].[OrderDetail] WITH CHECK ADD CONSTRAINT [FK_OrderDetail_Order] FOREIGN KEY([OrderId])
REFERENCES [dbo].[Order] ([OrderId]);
GO
ALTER TABLE [dbo].[OrderDetail] CHECK CONSTRAINT [FK_OrderDetail_Order];
GO

ALTER TABLE [dbo].[OrderDetail] WITH CHECK ADD CONSTRAINT [FK_OrderDetail_Product] FOREIGN KEY([ProductId])
REFERENCES [dbo].[Product] ([ProductId]);
GO
ALTER TABLE [dbo].[OrderDetail] CHECK CONSTRAINT [FK_OrderDetail_Product];
GO

---------------------------------------------------
-- 4. CHÈN DỮ LIỆU MẪU
---------------------------------------------------

-- Dữ liệu mẫu cho Category
SET IDENTITY_INSERT [dbo].[Category] ON
INSERT [dbo].[Category] ([CategoryId], [CategoryName]) VALUES (1, N'Electronics')
INSERT [dbo].[Category] ([CategoryId], [CategoryName]) VALUES (2, N'Apparel')
INSERT [dbo].[Category] ([CategoryId], [CategoryName]) VALUES (3, N'Books')
SET IDENTITY_INSERT [dbo].[Category] OFF
GO

-- Dữ liệu mẫu cho Product
SET IDENTITY_INSERT [dbo].[Product] ON
INSERT [dbo].[Product] ([ProductId], [CategoryId], [ProductName], [Weight], [UnitPrice], [UnitsInStock]) VALUES (1, 1, N'Laptop XYZ', 2.5, 1200.0000, 10)
INSERT [dbo].[Product] ([ProductId], [CategoryId], [ProductName], [Weight], [UnitPrice], [UnitsInStock]) VALUES (2, 1, N'Smartphone ABC', 0.2, 800.0000, 25)
INSERT [dbo].[Product] ([ProductId], [CategoryId], [ProductName], [Weight], [UnitPrice], [UnitsInStock]) VALUES (3, 2, N'T-Shirt Cotton', 0.3, 25.0000, 100)
INSERT [dbo].[Product] ([ProductId], [CategoryId], [ProductName], [Weight], [UnitPrice], [UnitsInStock]) VALUES (4, 2, N'Áo Khoác AA', 0.4, 412.0000, 3)
SET IDENTITY_INSERT [dbo].[Product] OFF
GO

-- Dữ liệu mẫu cho AspNetUsers (Lưu ý: Bạn phải tạo các Id hợp lệ trong ứng dụng .NET sau này)
-- Dữ liệu này chỉ mang tính chất minh họa Id và các trường tùy chỉnh (FirstName/LastName)
INSERT [dbo].[AspNetUsers] 
    ([Id], [UserName], [NormalizedUserName], [Email], [NormalizedEmail], [EmailConfirmed], 
     [PasswordHash], [SecurityStamp], [ConcurrencyStamp], [PhoneNumberConfirmed], [TwoFactorEnabled], 
     [LockoutEnabled], [AccessFailedCount], [FirstName], [LastName]) 
VALUES 
    (N'1c94411b-6060-4c74-a698-c4e954784a9e', N'admin@estore.com', N'ADMIN@ESTORE.COM', N'admin@estore.com', N'ADMIN@ESTORE.COM', 1, 
     N'hashed_password_admin', N'security_stamp_admin', N'concurrency_stamp_admin', 0, 0, 
     1, 0, N'eStore', N'Admin'), -- Id cho User 1 (Admin)
    (N'8e14b18c-3238-4e2e-8a23-380d0d826a7e', N'user1@estore.com', N'USER1@ESTORE.COM', N'user1@estore.com', N'USER1@ESTORE.COM', 1, 
     N'hashed_password_user', N'security_stamp_user', N'concurrency_stamp_user', 0, 0, 
     1, 0, N'User', N'One');     -- Id cho User 2 (Normal User)
GO

-- Dữ liệu mẫu cho Order (Sử dụng UserId đã tạo ở trên)
SET IDENTITY_INSERT [dbo].[Order] ON
INSERT [dbo].[Order] ([OrderId], [UserId], [OrderDate], [RequiredDate], [ShippedDate], [Freight]) 
VALUES 
    (1, N'8e14b18c-3238-4e2e-8a23-380d0d826a7e', CAST(N'2025-10-15T10:24:45.057' AS DateTime), CAST(N'2025-10-15T10:24:45.057' AS DateTime), CAST(N'2025-10-15T10:24:45.057' AS DateTime), 111.0000), -- User 2
    (2, N'8e14b18c-3238-4e2e-8a23-380d0d826a7e', CAST(N'2025-10-16T00:00:00.000' AS DateTime), CAST(N'2025-10-20T00:00:00.000' AS DateTime), NULL, 20.0000), -- User 2
    (3, N'1c94411b-6060-4c74-a698-c4e954784a9e', CAST(N'2004-10-10T00:00:00.000' AS DateTime), CAST(N'2025-10-10T00:00:00.000' AS DateTime), NULL, 10.0000)  -- User 1
SET IDENTITY_INSERT [dbo].[Order] OFF
GO

-- Dữ liệu mẫu cho OrderDetail
INSERT [dbo].[OrderDetail] ([OrderId], [ProductId], [UnitPrice], [Quantity], [Discount]) VALUES (1, 1, 1200.0000, 1, 0.05)
INSERT [dbo].[OrderDetail] ([OrderId], [ProductId], [UnitPrice], [Quantity], [Discount]) VALUES (1, 2, 800.0000, 4, 0.4)
GO